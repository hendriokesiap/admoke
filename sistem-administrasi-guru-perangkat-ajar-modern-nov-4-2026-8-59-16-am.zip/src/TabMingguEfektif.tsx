import React from 'react';
import {
  CalendarCheck,
  Edit3,
  Save,
  Download,
  Printer,
  Sun,
  Moon,
  Clock,
  CheckCircle2,
  Calendar,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';
import { RmeData, PekanBulan } from './dataMingguEfektif.ts';

interface TabMingguEfektifProps {
  rmeData: RmeData;
  setRmeData: React.Dispatch<React.SetStateAction<RmeData>>;
  isEditingRme: boolean;
  setIsEditingRme: (val: boolean) => void;
  handleSaveRme: () => void;
  rmeKelas: string;
  setRmeKelas: (kls: string) => void;
  rmeSemester: string;
  setRmeSemester: (sem: string) => void;
  identitas: {
    sekolah: string;
    tahunAjaran: string;
    guruPai: string;
    nipGuru: string;
    kepalaSekolah: string;
    nipKepsek: string;
    kota: string;
    tanggal: string;
    sapaanSiswa: string;
  };
  modules: any[];
  paperLightMode: boolean;
  setPaperLightMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  lineSpacing: string;
  setLineSpacing: (val: string) => void;
  handlePrintDocument: (elemId: string) => void;
  handleDownloadWord: (elemId: string, filename: string, isLandscape?: boolean) => void;
  showToast: (msg: string) => void;
  tableBorderClass: string;
  tableHeaderBgClass: string;
  docContainerClass: string;
  kopSuratUrl?: string;
  useKopSurat?: boolean;
}

export const TabMingguEfektif: React.FC<TabMingguEfektifProps> = ({
  rmeData,
  setRmeData,
  isEditingRme,
  setIsEditingRme,
  handleSaveRme,
  rmeKelas,
  setRmeKelas,
  rmeSemester,
  setRmeSemester,
  identitas,
  modules,
  paperLightMode,
  setPaperLightMode,
  lineSpacing,
  setLineSpacing,
  handlePrintDocument,
  handleDownloadWord,
  showToast,
  tableBorderClass,
  tableHeaderBgClass,
  docContainerClass,
  kopSuratUrl,
  useKopSurat
}) => {
  // Hitung fase berdasarkan kelas
  const faseKelas = rmeKelas === "I" || rmeKelas === "II" ? "A" : rmeKelas === "III" || rmeKelas === "IV" ? "B" : "C";

  // Hitung total minggu ganjil
  const totalGanjil = React.useMemo(() => {
    const totalMinggu = rmeData.ganjil.reduce((acc, cur) => acc + Number(cur.jmlMinggu || 0), 0);
    const totalTidakEfektif = rmeData.ganjil.reduce((acc, cur) => acc + Number(cur.tidakEfektif || 0), 0);
    const totalEfektif = rmeData.ganjil.reduce((acc, cur) => acc + Number(cur.efektif || 0), 0);
    const totalJp = totalEfektif * rmeData.bebanJpPerMinggu;
    return { totalMinggu, totalTidakEfektif, totalEfektif, totalJp };
  }, [rmeData.ganjil, rmeData.bebanJpPerMinggu]);

  // Hitung total minggu genap
  const totalGenap = React.useMemo(() => {
    const totalMinggu = rmeData.genap.reduce((acc, cur) => acc + Number(cur.jmlMinggu || 0), 0);
    const totalTidakEfektif = rmeData.genap.reduce((acc, cur) => acc + Number(cur.tidakEfektif || 0), 0);
    const totalEfektif = rmeData.genap.reduce((acc, cur) => acc + Number(cur.efektif || 0), 0);
    const totalJp = totalEfektif * rmeData.bebanJpPerMinggu;
    return { totalMinggu, totalTidakEfektif, totalEfektif, totalJp };
  }, [rmeData.genap, rmeData.bebanJpPerMinggu]);

  // Filter modul ajar kelas yang dipilih
  const modulKelasGanjil = React.useMemo(() => {
    return modules.filter((m) => m.kelas === rmeKelas && m.semester === "I (Ganjil)");
  }, [modules, rmeKelas]);

  const modulKelasGenap = React.useMemo(() => {
    return modules.filter((m) => m.kelas === rmeKelas && m.semester === "II (Genap)");
  }, [modules, rmeKelas]);

  // Helper update baris bulan
  const handleUpdateBulan = (semesterKey: "ganjil" | "genap", index: number, field: keyof PekanBulan, val: any) => {
    setRmeData((prev) => {
      const list = [...prev[semesterKey]];
      const target = { ...list[index], [field]: val };

      // Jika yang diubah jmlMinggu atau tidakEfektif, hitung otomatis efektifnya
      if (field === "jmlMinggu" || field === "tidakEfektif") {
        const jml = field === "jmlMinggu" ? Number(val) : Number(target.jmlMinggu);
        const tdk = field === "tidakEfektif" ? Number(val) : Number(target.tidakEfektif);
        target.efektif = Math.max(0, jml - tdk);
      }

      list[index] = target;
      return { ...prev, [semesterKey]: list };
    });
  };

  return (
    <div className="space-y-6">
      {/* TOOLBAR ATAS: FILTER, EDIT, SIMPAN, EXPORT & PRINT */}
      <div className="bg-white rounded-2xl border-2 border-emerald-300 p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 no-print shadow-sm text-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Tingkat Kelas:</span>
            <div className="flex bg-[#e6f7ef] p-1 rounded-xl border border-emerald-300">
              {["I", "II", "III", "IV", "V", "VI"].map((kls) => (
                <button
                  key={kls}
                  onClick={() => setRmeKelas(kls)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    rmeKelas === kls
                      ? "bg-[#065f46] text-white shadow-sm"
                      : "text-slate-700 hover:text-emerald-950 hover:bg-emerald-100"
                  }`}
                >
                  Kelas {kls}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Semester:</span>
            <select
              value={rmeSemester}
              onChange={(e) => setRmeSemester(e.target.value)}
              className="bg-white border border-slate-300 text-slate-900 text-xs font-bold rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
            >
              <option value="Semua">Semua Semester (Satu Tahun Penuh)</option>
              <option value="I (Ganjil)">Semester I (Ganjil)</option>
              <option value="II (Genap)">Semester II (Genap)</option>
            </select>
          </div>
        </div>

        {/* Action Buttons: Kertas, Spasi, Edit/Simpan, Word & Print */}
        <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
          {/* Toggle Spasi */}
          <button
            onClick={() => setLineSpacing(lineSpacing === "1.5" ? "1.15" : "1.5")}
            className="px-3 py-2 rounded-xl text-xs font-bold bg-white text-slate-800 border border-slate-300 hover:bg-emerald-50 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Ubah spasi baris dokumen resmi"
          >
            <Clock className="w-3.5 h-3.5 text-emerald-700" />
            <span>Spasi {lineSpacing}</span>
          </button>

          {/* Tombol Edit & Simpan Dokumen */}
          {isEditingRme ? (
            <button
              onClick={handleSaveRme}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#065f46] hover:bg-emerald-800 text-white shadow-sm flex items-center gap-2 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Perubahan</span>
            </button>
          ) : (
            <button
              onClick={() => setIsEditingRme(true)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-slate-800 border border-slate-300 flex items-center gap-2 transition-all cursor-pointer"
            >
              <Edit3 className="w-4 h-4 text-emerald-700" />
              <span>Edit Dokumen RME</span>
            </button>
          )}

          {/* Tombol Unduh Word */}
          <button
            onClick={() => handleDownloadWord("printable-area", `Rincian_Minggu_Efektif_Kelas_${rmeKelas}_PAI_${identitas.tahunAjaran.replace(/\//g, '-')}`)}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 flex items-center gap-2 transition-all shadow-xs cursor-pointer"
            title="Unduh dokumen resmi format Microsoft Word (.doc) A4 Margin 1.5 - 2.5 - 2.0 - 2.0"
          >
            <Download className="w-4 h-4 text-emerald-700" />
            <span>Unduh Word</span>
          </button>

          {/* Tombol Cetak / PDF */}
          <button
            onClick={() => handlePrintDocument("printable-area")}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#f59e0b] hover:bg-amber-600 text-slate-950 shadow-sm flex items-center gap-2 transition-all cursor-pointer"
            title="Cetak langsung atau simpan sebagai PDF A4 dengan margin 1.5 cm atas, 2.5 cm kiri, 2.0 cm kanan, 2.0 cm bawah"
          >
            <Printer className="w-4 h-4" />
            <span>Simpan PDF (A4)</span>
          </button>
        </div>
      </div>

      {/* DOKUMEN CETAK RESMI: RINCIAN MINGGU EFEKTIF */}
      <div
        id="printable-area"
        className={`max-w-4xl mx-auto rounded-3xl p-6 sm:p-12 transition-all border ${docContainerClass} official-doc-typography`}
        style={{ minHeight: "29.7cm" }}
      >
        {/* KOP SURAT RESMI SEKOLAH (Jika Diaktifkan) */}
        {useKopSurat && kopSuratUrl && (
          <div className="kop-surat-header mb-4 text-center">
            <img src={kopSuratUrl} alt="Kop Surat Resmi" className="kop-surat-img max-h-24 w-full object-contain mx-auto" />
            <div className="kop-surat-divider border-t-2 border-black mt-2 mb-4"></div>
          </div>
        )}

        {/* KOP / JUDUL DOKUMEN RESMI (Rapat Tanpa Spasi Antar Baris) */}
        <div className="doc-header-box text-center mb-6 border-b-2 border-black/80 pb-3 keep-together" style={{ lineHeight: 1.15 }}>
          <h2 className="doc-main-title font-bold text-base sm:text-lg tracking-wide uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            RINCIAN MINGGU EFEKTIF (RME)
          </h2>
          <h2 className="doc-main-title font-bold text-sm sm:text-base tracking-wide uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            DAN DISTRIBUSI ALOKASI WAKTU PEMBELAJARAN
          </h2>
          <h3 className="doc-sub-title font-bold text-xs sm:text-sm tracking-wide uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            MATA PELAJARAN PENDIDIKAN AGAMA ISLAM DAN BUDI PEKERTI
          </h3>
          <p className="text-xs sm:text-sm font-semibold uppercase" style={{ margin: 0, padding: 0, lineHeight: 1.15 }}>
            TAHUN AJARAN {identitas.tahunAjaran}
          </p>
        </div>

        {/* IDENTITAS DOKUMEN (Tanpa Tabel / Kotak, Susun Rapi Tanpa Spasi Berlebih) */}
        <div className="identitas-block mb-5 space-y-0.5 text-xs sm:text-[11pt] max-w-xl keep-together leading-tight" style={{ border: 'none', background: 'transparent', textAlign: 'left' }}>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-44 font-bold shrink-0">Satuan Pendidikan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">{identitas.sekolah}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-44 font-bold shrink-0">Mata Pelajaran</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val">Pendidikan Agama Islam dan Budi Pekerti</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-44 font-bold shrink-0">Kelas / Fase</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val font-bold">Kelas {rmeKelas} / Fase {faseKelas}</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-44 font-bold shrink-0">Beban Belajar Mingguan</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val">{rmeData.bebanJpPerMinggu} Jam Pelajaran (JP) / Minggu (@ 35 Menit)</span>
          </div>
          <div className="identitas-row flex items-baseline">
            <span className="identitas-label w-44 font-bold shrink-0">Tahun Ajaran / Semester</span>
            <span className="identitas-colon w-4 shrink-0 font-bold text-center">:</span>
            <span className="identitas-val">{identitas.tahunAjaran} / {rmeSemester === "Semua" ? "Semester I (Ganjil) & II (Genap)" : rmeSemester}</span>
          </div>
        </div>

        {/* ======================================================== */}
        {/* BAGIAN I: RINCIAN MINGGU EFEKTIF SEMESTER I (GANJIL)     */}
        {/* ======================================================== */}
        {(rmeSemester === "Semua" || rmeSemester === "I (Ganjil)") && (
          <div className="mb-10 space-y-4">
            <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
              A. PERHITUNGAN MINGGU EFEKTIF BELAJAR SEMESTER I (GANJIL)
            </h4>

            {/* TABEL PERHITUNGAN MINGGU SEMESTER GANJIL */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className={tableHeaderBgClass}>
                    <th className={`border px-2.5 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                    <th className={`border px-3 py-2 text-left font-bold w-28 ${tableBorderClass}`}>Nama Bulan</th>
                    <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Jumlah Minggu</th>
                    <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Minggu Tdk Efektif</th>
                    <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Minggu Efektif</th>
                    <th className={`border px-3 py-2 text-left font-bold ${tableBorderClass}`}>Keterangan Kegiatan Non-Efektif</th>
                  </tr>
                </thead>
                <tbody>
                  {rmeData.ganjil.map((item, idx) => (
                    <tr key={item.bulan}>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>{idx + 1}</td>
                      <td className={`border px-3 py-2 font-semibold ${tableBorderClass}`}>{item.bulan}</td>
                      <td className={`border px-2 py-2 text-center ${tableBorderClass}`}>
                        {isEditingRme ? (
                          <input
                            type="number"
                            min={0}
                            max={6}
                            value={item.jmlMinggu}
                            onChange={(e) => handleUpdateBulan("ganjil", idx, "jmlMinggu", e.target.value)}
                            className="w-14 text-center border rounded px-1 py-0.5 bg-transparent font-bold focus:ring-1 focus:ring-emerald-500"
                          />
                        ) : (
                          <span>{item.jmlMinggu}</span>
                        )}
                      </td>
                      <td className={`border px-2 py-2 text-center ${tableBorderClass}`}>
                        {isEditingRme ? (
                          <input
                            type="number"
                            min={0}
                            max={6}
                            value={item.tidakEfektif}
                            onChange={(e) => handleUpdateBulan("ganjil", idx, "tidakEfektif", e.target.value)}
                            className="w-14 text-center border rounded px-1 py-0.5 bg-transparent font-bold text-rose-500 focus:ring-1 focus:ring-emerald-500"
                          />
                        ) : (
                          <span className={item.tidakEfektif > 0 ? "text-rose-600 dark:text-rose-400 font-semibold" : ""}>
                            {item.tidakEfektif}
                          </span>
                        )}
                      </td>
                      <td className={`border px-2 py-2 text-center font-bold text-emerald-600 dark:text-emerald-400 ${tableBorderClass}`}>
                        {item.efektif}
                      </td>
                      <td className={`border px-3 py-2 ${tableBorderClass}`}>
                        {isEditingRme ? (
                          <input
                            type="text"
                            value={item.keterangan}
                            onChange={(e) => handleUpdateBulan("ganjil", idx, "keterangan", e.target.value)}
                            className="w-full border rounded px-2 py-0.5 bg-transparent text-xs focus:ring-1 focus:ring-emerald-500"
                          />
                        ) : (
                          <span>{item.keterangan || "-"}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                  {/* BARIS TOTAL GANJIL */}
                  <tr className={`font-bold ${tableHeaderBgClass}`}>
                    <td colSpan={2} className={`border px-3 py-2.5 text-center uppercase ${tableBorderClass}`}>
                      Jumlah Total Semester Ganjil
                    </td>
                    <td className={`border px-2 py-2.5 text-center ${tableBorderClass}`}>{totalGanjil.totalMinggu}</td>
                    <td className={`border px-2 py-2.5 text-center text-rose-600 dark:text-rose-400 ${tableBorderClass}`}>
                      {totalGanjil.totalTidakEfektif}
                    </td>
                    <td className={`border px-2 py-2.5 text-center text-emerald-600 dark:text-emerald-400 ${tableBorderClass}`}>
                      {totalGanjil.totalEfektif}
                    </td>
                    <td className={`border px-3 py-2.5 text-xs italic text-slate-500 dark:text-slate-400 ${tableBorderClass}`}>
                      Total Minggu Efektif KBM Semester 1
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* REKAPITULASI JUMLAH JAM PELAJARAN GANJIL */}
            <div className="p-4 rounded-xl border border-black/30 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 space-y-2 text-xs sm:text-sm keep-together">
              <h5 className="font-bold uppercase tracking-wider text-black dark:text-emerald-300">
                Rekapitulasi Jam Pelajaran (JP) Semester I (Ganjil):
              </h5>
              <ol className="list-decimal pl-5 space-y-1">
                <li>
                  Jumlah Minggu Efektif Belajar: <strong>{totalGanjil.totalEfektif} Minggu</strong>
                </li>
                <li>
                  Alokasi Waktu per Minggu: <strong>{rmeData.bebanJpPerMinggu} JP</strong>
                </li>
                <li>
                  Jumlah Jam Pelajaran Efektif (JPE): {totalGanjil.totalEfektif} × {rmeData.bebanJpPerMinggu} JP ={" "}
                  <strong className="text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                    {totalGanjil.totalJp} Jam Pelajaran (JP)
                  </strong>
                </li>
                <li>
                  Distribusi Alokasi Jam:
                  <ul className="list-disc pl-5 mt-1 space-y-0.5">
                    <li>
                      Tatap Muka Materi Pokok (Bab PAI Sem 1): <strong>{Math.max(0, totalGanjil.totalJp - rmeData.cadanganGanjil)} JP</strong>
                    </li>
                    <li>
                      Jam Cadangan & Asesmen Sumatif / Pengayaan: <strong>{rmeData.cadanganGanjil} JP</strong>
                    </li>
                  </ul>
                </li>
              </ol>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* BAGIAN II: RINCIAN MINGGU EFEKTIF SEMESTER II (GENAP)    */}
        {/* ======================================================== */}
        {(rmeSemester === "Semua" || rmeSemester === "II (Genap)") && (
          <div className="mb-10 space-y-4">
            <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
              {rmeSemester === "Semua" ? "B." : "A."} PERHITUNGAN MINGGU EFEKTIF BELAJAR SEMESTER II (GENAP)
            </h4>

            {/* TABEL PERHITUNGAN MINGGU SEMESTER GENAP */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className={tableHeaderBgClass}>
                    <th className={`border px-2.5 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                    <th className={`border px-3 py-2 text-left font-bold w-28 ${tableBorderClass}`}>Nama Bulan</th>
                    <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Jumlah Minggu</th>
                    <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Minggu Tdk Efektif</th>
                    <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Minggu Efektif</th>
                    <th className={`border px-3 py-2 text-left font-bold ${tableBorderClass}`}>Keterangan Kegiatan Non-Efektif</th>
                  </tr>
                </thead>
                <tbody>
                  {rmeData.genap.map((item, idx) => (
                    <tr key={item.bulan}>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>{idx + 1}</td>
                      <td className={`border px-3 py-2 font-semibold ${tableBorderClass}`}>{item.bulan}</td>
                      <td className={`border px-2 py-2 text-center ${tableBorderClass}`}>
                        {isEditingRme ? (
                          <input
                            type="number"
                            min={0}
                            max={6}
                            value={item.jmlMinggu}
                            onChange={(e) => handleUpdateBulan("genap", idx, "jmlMinggu", e.target.value)}
                            className="w-14 text-center border rounded px-1 py-0.5 bg-transparent font-bold focus:ring-1 focus:ring-emerald-500"
                          />
                        ) : (
                          <span>{item.jmlMinggu}</span>
                        )}
                      </td>
                      <td className={`border px-2 py-2 text-center ${tableBorderClass}`}>
                        {isEditingRme ? (
                          <input
                            type="number"
                            min={0}
                            max={6}
                            value={item.tidakEfektif}
                            onChange={(e) => handleUpdateBulan("genap", idx, "tidakEfektif", e.target.value)}
                            className="w-14 text-center border rounded px-1 py-0.5 bg-transparent font-bold text-rose-500 focus:ring-1 focus:ring-emerald-500"
                          />
                        ) : (
                          <span className={item.tidakEfektif > 0 ? "text-rose-600 dark:text-rose-400 font-semibold" : ""}>
                            {item.tidakEfektif}
                          </span>
                        )}
                      </td>
                      <td className={`border px-2 py-2 text-center font-bold text-emerald-600 dark:text-emerald-400 ${tableBorderClass}`}>
                        {item.efektif}
                      </td>
                      <td className={`border px-3 py-2 ${tableBorderClass}`}>
                        {isEditingRme ? (
                          <input
                            type="text"
                            value={item.keterangan}
                            onChange={(e) => handleUpdateBulan("genap", idx, "keterangan", e.target.value)}
                            className="w-full border rounded px-2 py-0.5 bg-transparent text-xs focus:ring-1 focus:ring-emerald-500"
                          />
                        ) : (
                          <span>{item.keterangan || "-"}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                  {/* BARIS TOTAL GENAP */}
                  <tr className={`font-bold ${tableHeaderBgClass}`}>
                    <td colSpan={2} className={`border px-3 py-2.5 text-center uppercase ${tableBorderClass}`}>
                      Jumlah Total Semester Genap
                    </td>
                    <td className={`border px-2 py-2.5 text-center ${tableBorderClass}`}>{totalGenap.totalMinggu}</td>
                    <td className={`border px-2 py-2.5 text-center text-rose-600 dark:text-rose-400 ${tableBorderClass}`}>
                      {totalGenap.totalTidakEfektif}
                    </td>
                    <td className={`border px-2 py-2.5 text-center text-emerald-600 dark:text-emerald-400 ${tableBorderClass}`}>
                      {totalGenap.totalEfektif}
                    </td>
                    <td className={`border px-3 py-2.5 text-xs italic text-slate-500 dark:text-slate-400 ${tableBorderClass}`}>
                      Total Minggu Efektif KBM Semester 2
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* REKAPITULASI JUMLAH JAM PELAJARAN GENAP */}
            <div className="p-4 rounded-xl border border-black/30 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/40 space-y-2 text-xs sm:text-sm keep-together">
              <h5 className="font-bold uppercase tracking-wider text-black dark:text-emerald-300">
                Rekapitulasi Jam Pelajaran (JP) Semester II (Genap):
              </h5>
              <ol className="list-decimal pl-5 space-y-1">
                <li>
                  Jumlah Minggu Efektif Belajar: <strong>{totalGenap.totalEfektif} Minggu</strong>
                </li>
                <li>
                  Alokasi Waktu per Minggu: <strong>{rmeData.bebanJpPerMinggu} JP</strong>
                </li>
                <li>
                  Jumlah Jam Pelajaran Efektif (JPE): {totalGenap.totalEfektif} × {rmeData.bebanJpPerMinggu} JP ={" "}
                  <strong className="text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                    {totalGenap.totalJp} Jam Pelajaran (JP)
                  </strong>
                </li>
                <li>
                  Distribusi Alokasi Jam:
                  <ul className="list-disc pl-5 mt-1 space-y-0.5">
                    <li>
                      Tatap Muka Materi Pokok (Bab PAI Sem 2): <strong>{Math.max(0, totalGenap.totalJp - rmeData.cadanganGenap)} JP</strong>
                    </li>
                    <li>
                      Jam Cadangan & Asesmen Sumatif / Pengayaan: <strong>{rmeData.cadanganGenap} JP</strong>
                    </li>
                  </ul>
                </li>
              </ol>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* BAGIAN III: DISTRIBUSI ALOKASI WAKTU KE BAB / MATERI     */}
        {/* ======================================================== */}
        <div className="mb-10 space-y-4">
          <h4 className="doc-section-heading font-bold text-xs sm:text-sm uppercase tracking-wide border-b border-black pb-1">
            {rmeSemester === "Semua" ? "C." : "B."} DISTRIBUSI ALOKASI WAKTU PEMBELAJARAN PER BAB (KELAS {rmeKelas})
          </h4>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
            Berikut rincian pembagian jam pelajaran efektif untuk setiap Bab/Lingkup Materi Pembelajaran Pendidikan Agama Islam dan Budi Pekerti Kelas {rmeKelas} sesuai Alur Tujuan Pembelajaran (ATP):
          </p>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-xs sm:text-sm">
              <thead>
                <tr className={tableHeaderBgClass}>
                  <th className={`border px-2 py-2 text-center font-bold w-10 ${tableBorderClass}`}>No</th>
                  <th className={`border px-3 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Semester</th>
                  <th className={`border px-3 py-2 text-left font-bold ${tableBorderClass}`}>Bab / Lingkup Materi Pokok</th>
                  <th className={`border px-3 py-2 text-left font-bold w-36 ${tableBorderClass}`}>Elemen</th>
                  <th className={`border px-2 py-2 text-center font-bold w-20 ${tableBorderClass}`}>Alokasi JP</th>
                  <th className={`border px-2 py-2 text-center font-bold w-24 ${tableBorderClass}`}>Jml Pertemuan</th>
                </tr>
              </thead>
              <tbody>
                {/* Modul Semester 1 */}
                {(rmeSemester === "Semua" || rmeSemester === "I (Ganjil)") &&
                  modulKelasGanjil.map((m, idx) => (
                    <tr key={m.id}>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>{idx + 1}</td>
                      <td className={`border px-3 py-2 text-center text-xs font-semibold ${tableBorderClass}`}>Semester 1</td>
                      <td className={`border px-3 py-2 ${tableBorderClass}`}>
                        <div className="font-bold text-xs sm:text-sm">Bab {m.nomor}: {m.tp.split('.')[0]}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">{m.tp}</div>
                      </td>
                      <td className={`border px-3 py-2 text-xs font-medium ${tableBorderClass}`}>{m.elemen}</td>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>{m.alokasi}</td>
                      <td className={`border px-2 py-2 text-center ${tableBorderClass}`}>{m.pertemuan?.length || 3} Pertemuan</td>
                    </tr>
                  ))}

                {(rmeSemester === "Semua" || rmeSemester === "I (Ganjil)") && (
                  <tr className="bg-slate-50 dark:bg-slate-800/40 italic">
                    <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>*</td>
                    <td className={`border px-3 py-1.5 text-center text-xs ${tableBorderClass}`}>Semester 1</td>
                    <td colSpan={2} className={`border px-3 py-1.5 font-medium ${tableBorderClass}`}>
                      Cadangan Jam Pelajaran & Asesmen Sumatif Semester Ganjil
                    </td>
                    <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>{rmeData.cadanganGanjil} JP</td>
                    <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`}>2 Pertemuan</td>
                  </tr>
                )}

                {/* Modul Semester 2 */}
                {(rmeSemester === "Semua" || rmeSemester === "II (Genap)") &&
                  modulKelasGenap.map((m, idx) => (
                    <tr key={m.id}>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>
                        {rmeSemester === "Semua" ? modulKelasGanjil.length + idx + 1 : idx + 1}
                      </td>
                      <td className={`border px-3 py-2 text-center text-xs font-semibold ${tableBorderClass}`}>Semester 2</td>
                      <td className={`border px-3 py-2 ${tableBorderClass}`}>
                        <div className="font-bold text-xs sm:text-sm">Bab {m.nomor}: {m.tp.split('.')[0]}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">{m.tp}</div>
                      </td>
                      <td className={`border px-3 py-2 text-xs font-medium ${tableBorderClass}`}>{m.elemen}</td>
                      <td className={`border px-2 py-2 text-center font-bold ${tableBorderClass}`}>{m.alokasi}</td>
                      <td className={`border px-2 py-2 text-center ${tableBorderClass}`}>{m.pertemuan?.length || 3} Pertemuan</td>
                    </tr>
                  ))}

                {(rmeSemester === "Semua" || rmeSemester === "II (Genap)") && (
                  <tr className="bg-slate-50 dark:bg-slate-800/40 italic">
                    <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>*</td>
                    <td className={`border px-3 py-1.5 text-center text-xs ${tableBorderClass}`}>Semester 2</td>
                    <td colSpan={2} className={`border px-3 py-1.5 font-medium ${tableBorderClass}`}>
                      Cadangan Jam Pelajaran & Asesmen Sumatif Akhir Tahun (SAT)
                    </td>
                    <td className={`border px-2 py-1.5 text-center font-bold ${tableBorderClass}`}>{rmeData.cadanganGenap} JP</td>
                    <td className={`border px-2 py-1.5 text-center ${tableBorderClass}`}>2 Pertemuan</td>
                  </tr>
                )}

                {/* Baris Total Alokasi Jam Satu Tahun */}
                <tr className={`font-bold ${tableHeaderBgClass}`}>
                  <td colSpan={4} className={`border px-3 py-2 text-right uppercase ${tableBorderClass}`}>
                    Total Alokasi Jam Pelajaran {rmeSemester === "Semua" ? "Satu Tahun (Sem 1 & 2)" : rmeSemester}
                  </td>
                  <td className={`border px-2 py-2 text-center text-emerald-600 dark:text-emerald-400 font-extrabold ${tableBorderClass}`}>
                    {rmeSemester === "Semua"
                      ? `${totalGanjil.totalJp + totalGenap.totalJp} JP`
                      : rmeSemester === "I (Ganjil)"
                      ? `${totalGanjil.totalJp} JP`
                      : `${totalGenap.totalJp} JP`}
                  </td>
                  <td className={`border px-2 py-2 text-center text-xs ${tableBorderClass}`}>
                    {rmeSemester === "Semua"
                      ? `${totalGanjil.totalEfektif + totalGenap.totalEfektif} Minggu`
                      : rmeSemester === "I (Ganjil)"
                      ? `${totalGanjil.totalEfektif} Minggu`
                      : `${totalGenap.totalEfektif} Minggu`}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* TANDA TANGAN PENGESAHAN RESMI (Tabel 2 Kolom Horizontal Tanpa Kotak Garis) */}
              <table className="ttd-table no-border w-full mt-10" style={{ width: '100%', border: 'none', borderCollapse: 'collapse', background: 'transparent', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                <tbody>
                  <tr style={{ border: 'none', background: 'transparent' }}>
                    <td className="ttd-left" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 15px 0 0', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Mengetahui,</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Kepala Sekolah / Satuan Pendidikan</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kepalaSekolah}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipKepsek}</p>
                    </td>
                    <td className="ttd-right" style={{ width: '50%', verticalAlign: 'top', textAlign: 'left', border: 'none', padding: '0 0 0 30px', background: 'transparent' }}>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.kota}, {identitas.tanggal}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>Guru PAI dan BP</p>
                      <div style={{ height: "70px", minHeight: "70px" }}></div>
                      <p className="font-bold underline" style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>{identitas.guruPai}</p>
                      <p style={{ margin: 0, padding: 0, textAlign: "left", lineHeight: 1.35, fontSize: "11pt" }}>NIP. {identitas.nipGuru}</p>
                    </td>
                  </tr>
                </tbody>
              </table>
      </div>
    </div>
  );
};

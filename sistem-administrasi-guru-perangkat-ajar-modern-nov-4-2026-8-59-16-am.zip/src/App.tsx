import PerangkatAjarApp from './AplikasiPerangkatAjar.tsx';

export default function App() {
  return <PerangkatAjarApp />;
}

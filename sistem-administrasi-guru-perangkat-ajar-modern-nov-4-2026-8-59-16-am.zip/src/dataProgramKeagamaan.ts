/**
 * Data Default & Struktur Program Keagamaan Islam SD
 * Disusun dengan Redaksi Profesional Sesuai Ketentuan Pendidikan di Indonesia
 * (Kurikulum Merdeka, UU Sisdiknas No. 20/2003, PP SNP No. 57/2021 & PP No. 4/2022, Permendikbudristek No. 12/2024, KMA No. 211/2011)
 */

export interface KegiatanPhbi {
  id: string;
  nama: string;
  waktu: string;
  tema: string;
  sasaran: string;
  penanggungJawab: string;
  bentukKegiatan: string[];
}

export interface JadwalJumat {
  pekan: string;
  kegiatan: string;
  deskripsi: string;
  tujuan: string;
}

export interface MatriksProgram {
  no: number;
  kegiatan: string;
  waktu: string;
  sasaran: string;
  penanggungJawab: string;
  indikator: string;
}

export interface ProgramKeagamaanData {
  judul: string;
  subJudul: string;
  latarBelakang: string;
  dasarHukum: string[];
  tujuan: string[];
  phbi: KegiatanPhbi[];
  jumatPagi: {
    waktuPelaksanaan: string;
    tempat: string;
    mekanisme: string;
    jadwal: JadwalJumat[];
  };
  matriks: MatriksProgram[];
  penutup: string;
}

export const DEFAULT_PROGRAM_KEAGAMAAN: ProgramKeagamaanData = {
  judul: "PROGRAM PEMBIASAAN DAN KEGIATAN KEAGAMAAN ISLAM SEKOLAH DASAR",
  subJudul: "TAHUN AJARAN 2024/2025",
  latarBelakang: "Pendidikan Agama Islam dan Budi Pekerti di Sekolah Dasar memiliki kedudukan yang sangat fundamental dalam pembentukan akidah, akhlak mulia, serta kepribadian religius peserta didik sejak usia dini. Sejalan dengan arah kebijakan Kurikulum Merdeka yang berorientasi pada terwujudnya Profil Pelajar Pancasila—khususnya pada dimensi Beriman, Bertakwa kepada Tuhan Yang Maha Esa, dan Berakhlak Mulia—pembelajaran agama tidak boleh sekadar berhenti pada pemenuhan aspek kognitif di ruang kelas semata, melainkan harus bertransformasi menjadi pembiasaan hidup beragama (amaliyah yaumiyyah), budaya religius sekolah (religious school culture), dan peneladanan budi pekerti luhur.\n\nLingkungan sekolah dasar adalah masa pembentukan karakter (formative golden years) yang sangat strategis. Oleh karenanya, diperlukan program pembiasaan harian, mingguan, dan peringatan hari besar keagamaan yang terencana, terpadu, dan berkesinambungan. Program ini dirancang untuk menciptakan iklim sekolah yang damai, santun, toleran, dan berkeadaban islami, sekaligus menjadi sarana implementasi pendekatan Pembelajaran Mendalam (Mindful, Meaningful, dan Joyful Learning).",
  dasarHukum: [
    "Undang-Undang Republik Indonesia Nomor 20 Tahun 2003 tentang Sistem Pendidikan Nasional (Pasal 3 mengenai fungsi dan tujuan pendidikan nasional, serta Pasal 12 ayat 1a mengenai hak peserta didik mendapatkan pendidikan agama sesuai dengan agama yang dianutnya).",
    "Peraturan Pemerintah Republik Indonesia Nomor 57 Tahun 2021 tentang Standar Nasional Pendidikan sebagaimana telah diubah dengan Peraturan Pemerintah Nomor 4 Tahun 2022.",
    "Peraturan Menteri Pendidikan, Kebudayaan, Riset, dan Teknologi Nomor 12 Tahun 2024 tentang Kurikulum pada Pendidikan Anak Usia Dini, Jenjang Pendidikan Dasar, dan Jenjang Pendidikan Menengah.",
    "Keputusan Menteri Agama (KMA) Republik Indonesia Nomor 211 Tahun 2011 tentang Pedoman Pengembangan Standar Nasional Pendidikan Agama Islam pada Sekolah.",
    "Peraturan Menteri Pendidikan dan Kebudayaan Nomor 23 Tahun 2015 tentang Penumbuhan Budi Pekerti pada Satuan Pendidikan.",
    "Keputusan Kepala Badan Standar, Kurikulum, dan Asesmen Pendidikan (BSKAP) Kemendikbudristek Nomor 032/H/KR/2024 tentang Capaian Pembelajaran pada Kurikulum Merdeka."
  ],
  tujuan: [
    "Menumbuhkembangkan keimanan dan ketakwaan peserta didik kepada Allah Swt. melalui pengamalan ibadah wajib dan sunah secara istiqamah.",
    "Membudayakan pembiasaan salat dhuha, tadarus Al-Qur'an (tahsin & tahfidz), zikir, doa, dan infaq shadaqah harian/mingguan di lingkungan sekolah.",
    "Menginternalisasikan nilai-nilai suri teladan Rasulullah SAW dan menghayati makna peristiwa sejarah Islam melalui Peringatan Hari Besar Islam (PHBI).",
    "Membentuk karakter santun, tawadhu', toleran (tasamuh), mandiri, dan berakhlakul karimah dalam interaksi di sekolah, keluarga, dan masyarakat.",
    "Mempererat tali ukhuwah islamiyah dan sinergi kemitraan antara pendidik, peserta didik, orang tua/wali murid, dan komite sekolah."
  ],
  phbi: [
    {
      id: "phbi-1",
      nama: "Peringatan Tahun Baru Islam (1 Muharram)",
      waktu: "Bulan Muharram (Awal Semester Ganjil)",
      tema: "Semangat Hijrah Menuju Pribadi yang Bertakwa, Berakhlak Mulia, Disiplin, dan Berprestasi",
      sasaran: "Seluruh Peserta Didik (Kelas I - VI), Pendidik, dan Tenaga Kependidikan",
      penanggungJawab: "Guru PAI & BP dibantu Tim Kesiswaan Sekolah",
      bentukKegiatan: [
        "Pawai Muharram dan Syiar Islami di lingkungan sekitar satuan pendidikan dengan poster pesan-pesan moral Al-Qur'an.",
        "Santunan Peduli Muharram untuk peserta didik yatim, piatu, dan dhuafa di lingkungan sekolah sebagai wujud kepedulian sosial.",
        "Tausiyah edukatif bertema keutamaan bulan Muharram dan refleksi peristiwa hijrah Nabi Muhammad SAW.",
        "Lomba kreasi islami: Lomba Mewarnai Kaligrafi (Fase A), Lomba Dai Cilik/Pildacil (Fase B & C), dan Lomba Cerdas Cermat Islami."
      ]
    },
    {
      id: "phbi-2",
      nama: "Peringatan Maulid Nabi Muhammad SAW (12 Rabiul Awal)",
      waktu: "Bulan Rabiul Awal (Semester Ganjil)",
      tema: "Meneladani Akhlakul Karimah Rasulullah SAW Sebagai Uswatun Hasanah Generasi Rabbani di Era Digital",
      sasaran: "Seluruh Warga Sekolah, Orang Tua/Wali Murid, dan Komite Sekolah",
      penanggungJawab: "Kepala Sekolah & Tim Pembina Keagamaan PAI",
      bentukKegiatan: [
        "Pembacaan Sholawat Nabi (Simtudduror / Diba'iyyah / Barzanji) secara berjamaah untuk melatih kecintaan kepada Rasulullah SAW.",
        "Kajian Sirah Nabawiyah tematik tentang keteladanan kejujuran (shiddiq), amanah, tabligh, dan fathanah Nabi Muhammad SAW.",
        "Festival Seni & Kreasi PAI: Lomba Azan dan Iqamah, Lomba Hafalan Surat Pendek Juz 'Amma (Tahfidz), Busana Muslim, dan Kaligrafi.",
        "Bazar Makanan Sehat Berkah dan Aksi Sedekah Barokah Maulid."
      ]
    },
    {
      id: "phbi-3",
      nama: "Peringatan Isra' Mi'raj Nabi Muhammad SAW (27 Rajab)",
      waktu: "Bulan Rajab (Semester Genap)",
      tema: "Membumikan Hakikat Ibadah Salat Fardu Sebagai Fondasi Moral, Kejujuran, dan Kedisiplinan Peserta Didik",
      sasaran: "Seluruh Peserta Didik (Kelas I - VI) dan Dewan Guru",
      penanggungJawab: "Guru PAI & BP",
      bentukKegiatan: [
        "Peringatan Isra' Mi'raj dan Tabligh Akbar diiringi muhasabah spiritual bersama narasumber tamu.",
        "Bimbingan Praktik Thaharah (Wudhu dan Tayamum) serta Gerakan dan Bacaan Salat Fardu Sempurna Sesuai Tuntunan Sunnah.",
        "Gerakan 'Ayo Tertib Salat 5 Waktu' dengan pembagian buku kontrol ibadah harian peserta didik.",
        "Penayangan media audio-visual edukatif mengenai perjalanan suci Isra' Mi'raj dan perintah salat lima waktu."
      ]
    }
  ],
  jumatPagi: {
    waktuPelaksanaan: "Setiap Hari Jumat, Pukul 06.45 - 07.45 WIB (Sebelum KBM Dimulai)",
    tempat: "Halaman Utama Sekolah / Mushala Sekolah / Aula Terbuka",
    mekanisme: "Sistem Bergantian Terstruktur Tiap Pekan (Rotating Scheme Pekan I s.d IV)",
    jadwal: [
      {
        pekan: "Jumat Pekan I",
        kegiatan: "Salat Dhuha Berjamaah & Kultum Akhlakul Karimah",
        deskripsi: "Pelaksanaan salat sunah dhuha secara berjamaah sebanyak 2 hingga 4 rakaat dipimpin oleh Guru PAI atau imam perwakilan peserta didik kelas tinggi secara bergiliran. Dilanjutkan dengan pembacaan doa salat dhuha bersama dan kuliah tujuh menit (kultum) bertema adab terhadap orang tua, guru, dan teman sesama muslim.",
        tujuan: "Membiasakan peserta didik menjaga ibadah sunah dhuha untuk membuka pintu keberkahan belajar serta melatih kepercayaan diri dan kepemimpinan dai cilik."
      },
      {
        pekan: "Jumat Pekan II",
        kegiatan: "Zikir Bersama, Doa Ma'tsurat & Pelantunan 99 Asmaul Husna",
        deskripsi: "Pelafalan zikir pagi (Al-Ma'tsurat Sughra), istighfar, tasbih, tahmid, tahlil secara khusyuk dan dipandu mikrofon sentral. Dilanjutkan melantunkan nada irama merdu 99 Asmaul Husna bersama-sama, mendalami makna salah satu asmaul husna pilihan, serta doa bersama untuk kebaikan diri, kedua orang tua, guru, sekolah, dan bangsa Indonesia.",
        tujuan: "Menanamkan ketenangan jiwa (thuma'ninah), menyucikan hati peserta didik, serta menumbuhkan mahabbah dan keyakinan mutlak kepada sifat-sifat agung Allah Swt."
      },
      {
        pekan: "Jumat Pekan III",
        kegiatan: "Tahsin & Tahfidz Al-Qur'an (Juz 30 / Juz 'Amma & Doa Harian)",
        deskripsi: "Pembiasaan membaca ayat-ayat suci Al-Qur'an secara tartil dengan bimbingan makharijul huruf dan hukum tajwid (tahsin). Dilanjutkan dengan setoran hafalan mandiri dan muraja'ah bersama surat-surat pendek pilihan (Q.S. An-Nas hingga Q.S. Ad-Duha) disesuaikan target ATP Fase A, B, dan C, serta hafalan doa harian praktis.",
        tujuan: "Memastikan seluruh peserta didik fasih membaca Al-Qur'an sejak dini dan mencapai target hafalan minimal juz 30 sesuai capaian kurikulum."
      },
      {
        pekan: "Jumat Pekan IV",
        kegiatan: "Gerakan Infaq Jumat Barokah & Aksi Peduli Lingkungan 'An-Nadhafatu Minal Iman'",
        deskripsi: "Penggalangan kotak infaq sukarela dari peserta didik untuk membina kepekaan sosial dan kedermawanan, yang hasilnya dicatat transparan untuk santunan teman sakit, bantuan perlengkapan mushala, atau kegiatan sosial. Dilanjutkan aksi gotong royong membersihkan kelas, tempat wudhu, dan halaman sekolah dengan prinsip 'Kebersihan adalah sebagian dari iman'.",
        tujuan: "Mengaktualisasikan keimanan ke dalam perbuatan konkret berupa kedermawanan sosial dan kepedulian terhadap kebersihan lingkungan belajar."
      }
    ]
  },
  matriks: [
    {
      no: 1,
      kegiatan: "Salat Dhuha Berjamaah & Kultum",
      waktu: "Jumat Pekan I (06.45 - 07.45)",
      sasaran: "Kelas I - VI",
      penanggungJawab: "Guru PAI & Guru Piket",
      indikator: "Terselenggara salat berjamaah khusyuk, absensi kehadiran, dan ringkasan kultum"
    },
    {
      no: 2,
      kegiatan: "Zikir Pagi & Pelantunan 99 Asmaul Husna",
      waktu: "Jumat Pekan II (06.45 - 07.45)",
      sasaran: "Kelas I - VI",
      penanggungJawab: "Guru PAI & Guru Kelas",
      indikator: "Peserta didik hafal dan mampu melantunkan Asmaul Husna beserta artinya"
    },
    {
      no: 3,
      kegiatan: "Tahsin & Tahfidz Al-Qur'an Juz 30",
      waktu: "Jumat Pekan III (06.45 - 07.45)",
      sasaran: "Kelas I - VI",
      penanggungJawab: "Guru PAI & Pembina Ekskul BTQ",
      indikator: "Buku mutaba'ah/kartu setoran hafalan Juz 30 terisi teratur dan bertarget"
    },
    {
      no: 4,
      kegiatan: "Infaq Jumat Barokah & Aksi Bersih Lingkungan",
      waktu: "Jumat Pekan IV (06.45 - 07.45)",
      sasaran: "Kelas I - VI",
      penanggungJawab: "Tim Kesiswaan & Bendahara PAI",
      indikator: "Buku kas infaq transparan dan lingkungan mushala/sekolah bersih rapi"
    },
    {
      no: 5,
      kegiatan: "PHBI Tahun Baru Islam (1 Muharram)",
      waktu: "Bulan Muharram (Awal Semester 1)",
      sasaran: "Seluruh Warga Sekolah",
      penanggungJawab: "Panitia PHBI & Guru PAI",
      indikator: "Laporan kegiatan pawai, dokumentasi santunan yatim, dan sertifikat lomba"
    },
    {
      no: 6,
      kegiatan: "PHBI Maulid Nabi Muhammad SAW",
      waktu: "12 Rabiul Awal (Semester 1)",
      sasaran: "Warga Sekolah & Komite",
      penanggungJawab: "Panitia PHBI & Kepala Sekolah",
      indikator: "Kajian sirah terlaksana, sholawat berjamaah, dan festival pentas seni PAI"
    },
    {
      no: 7,
      kegiatan: "PHBI Isra' Mi'raj Nabi Muhammad SAW",
      waktu: "27 Rajab (Semester 2)",
      sasaran: "Warga Sekolah & Siswa",
      penanggungJawab: "Panitia PHBI & Guru PAI",
      indikator: "Bimbingan salat dan pemutaran film edukasi terlaksana serta buku kontrol salat"
    }
  ],
  penutup: "Program Pembiasaan dan Kegiatan Keagamaan Islam ini disusun sebagai pedoman operasional dalam mewujudkan ekosistem sekolah yang religius, berkarakter, dan berdaya saing luhur. Keberhasilan program ini sangat bergantung pada komitmen, keteladanan pendidik dan tenaga kependidikan, serta sinergi kemitraan yang harmonis antara pihak sekolah, orang tua/wali murid, komite sekolah, dan masyarakat sekitar. Semoga Allah Swt. senantiasa meridhoi setiap langkah ikhtiar kita dalam membina generasi saleh dan salehah yang berakhlakul karimah serta cinta tanah air."
};
